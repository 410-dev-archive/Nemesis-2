#!/bin/bash
curl -Ls "$1" -o "$2"
